//
// Created by kripe on 24.09.2026.
//

#ifndef DEQUE_H
#define DEQUE_H
#include <stdlib.h>
#include <stdio.h>

#endif //DEQUE_H

#pragma once

typedef struct NodeDeque {
	long long data;
	struct NodeDeque* next, *prev;
} NodeDeque;

NodeDeque* newNodeDeque(long long data, NodeDeque* next, NodeDeque* prev);

typedef struct Deque {
	NodeDeque* head;
	NodeDeque* tail;
	long long size;
} Deque;

Deque* newDeque();

void pushFrontDeque(Deque* deque, long long data);

long long popFrontDeque(Deque* deque);

void pushBackDeque(Deque* deque, long long data);

long long popBackDeque(Deque* deque);

void deleteNodeDeque(NodeDeque* deque);

void deleteDeque(Deque* deque);

void printNodeDeque(NodeDeque* nodeDeque);

void printDeque(Deque* deque);
