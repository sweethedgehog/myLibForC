//
// Created by kripe on 24.09.2026.
//

#ifndef VECTOR_H
#define VECTOR_H
#include <stdlib.h>

#endif //VECTOR_H

#pragma once

typedef struct Vector {
	long long size;
	long long capacity;
	long long *data;
} Vector;

Vector *newVector(long long size);

void deleteVector(Vector *vec);

void removeVector(Vector *vec, long long index);

void resizeVector(Vector* vec);

void pushBackVector(Vector *vec, long long value);

long long getVector(Vector *vec, long long index);

void setVector(Vector *vec, long long index, long long value);

void sort(long long* data, long long size);