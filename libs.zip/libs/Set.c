//
// Created by kripe on 25.09.2026.
//
#include "Set.h"

Set* newSet() {
	Set* set = (Set*)malloc(sizeof(Set));
	set->root = NULL;
	set->size = 0;
	return set;
}

Node* newNodeSet(long long data, Node* left, Node* right) {
	Node* node = (Node*)malloc(sizeof(Node));
	node->data = data;
	node->left = left;
	node->right = right;
	node->key = rand();
	return node;
}

void deleteTree(Node* node) {
	if (node == NULL) return;
	if (node->left) deleteTree(node->left);
	if (node->right) deleteTree(node->right);
}

_Bool _find(Node* root, long long a) {
	if (root == NULL) return 0;
	if (a == root->data) return 1;
	if (root->data > a) return _find(root->left, a);
	return _find(root->right, a);
}

_Bool find(Set* set, long long a) { return _find(set->root, a); }

Node* upper(Node* root) {
	if (root == NULL) return NULL;
	Node* buf = upper(root->right);
	if (buf) return root;
	return buf;
}

Node* lower(Node* root) {
	if (root == NULL) return NULL;
	Node* buf = upper(root->left);
	if (buf) return root;
	return buf;
}

NodePair setNodePair(Node* l, Node* r) {
	NodePair nodePair;
	nodePair.l = l;
	nodePair.r = r;
	return nodePair;
}

NodePair split(Node* root, long long a) {
	if (root == NULL) return setNodePair(NULL, NULL);
	if (root->data <= a) {
		NodePair buf = split(root->right, a);
		Node* left = buf.l, *right = buf.r;
		root->right = left;
		return setNodePair(root, right);
	}
	NodePair buf = split(root->left, a);
	Node* left = buf.l, *right = buf.r;
	root->left = right;
	return setNodePair(left, root);
}

Node* merge(Node* left, Node* right) {
	if (left == NULL) return right;
	if (right == NULL) return left;
	if (left->key > right->key) {
		left->right = merge(left->right, right);
		return left;
	}
	right->left = merge(left, right->left);
	return right;
}

void insert(Set* set, long long a) {
	if (_find(set->root, a)) return;
	set->size++;
	NodePair buf = split(set->root, a);
	Node* node = newNodeSet(a, NULL, NULL);
	set->root = merge(merge(buf.l, node), buf.r);
}

Node* _remove(Node* root, long long a) {
	if (!root) return NULL;
	if (root->data == a) {
		Node* buf = merge(root->left, root->right);
		free(root);
		return buf;
	}
	if (root->data < a) root->right = _remove(root->right, a);
	else root->left = _remove(root->left, a);
	return root;
}

void removeSet(Set* set, long long a) { set->root = _remove(set->root, a); }

void printNodes(Node* root) {
	if (root == NULL) return;
	printNodes(root->left);
	printf("%lld ", root->data);
	printNodes(root->right);
}

void printSet(Set* set) {
	printNodes(set->root);
	printf("\n");
}