//
// Created by kripe on 24.09.2026.
//

#ifndef SET_H
#define SET_H
#include <stdio.h>
#include <stdlib.h>

#endif //SET_H

#pragma once

typedef struct Node {
	long long data;
	long long key /*= rand_int(INT_MIN, INT_MAX)*/;
	struct Node* left;
	struct Node* right;
} Node;

typedef struct NodePair {
	Node* l,* r;
} NodePair;

typedef struct Set {
	Node* root;
	long long size;
} Set;

Set* newSet();

Node* newNodeSet(long long data, Node* left, Node* right);

void deleteTree(Node* node);

_Bool _find(Node* root, long long a);

_Bool find(Set* set, long long a);

Node* upper(Node* root);

Node* lower(Node* root);

NodePair setNodePair(Node* l, Node* r);

NodePair split(Node* root, long long a);

Node* merge(Node* left, Node* right);

void insert(Set* set, long long a);

Node* _remove(Node* root, long long a);

void removeSet(Set* set, long long a);

void printNodes(Node* root);

void printSet(Set* set);